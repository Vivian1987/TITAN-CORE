#!/usr/bin/env python3
"""Audit the ps5-payload-sdk libSceAmpr PRX and corrected SysV hash."""

from __future__ import annotations

import argparse
import re
import struct
import sys
from pathlib import Path

from generate_payload_exports import METADATA_SYMBOLS, defined_exports, name_to_nid
from prx_hash_fix import Elf64LE, buckets_to_symbol_map, elf_hash


IMPORT_RE = re.compile(r"^[A-Za-z0-9+\-]{11}#[A-Za-z0-9+\-]#[A-Za-z0-9+\-]$")
EXPECTED_PHDR_TYPES = [
    1, 1, 1, 0x6474E552, 1, 0x61000002, 2, 7,
    0x6474E550, 1, 0x6FFFFF00, 0x6FFFFF01, 4, 4,
]
EXPECTED_MODULE_PARAM = bytes.fromhex(
    "2000000000000000 bff4133c03000000 0100050809000002 0100000000000000"
)
EXPECTED_SCEVERSION = bytes.fromhex(
    "0000160008637274693a02000009000000010200000900000001"
    "00001b0008637274626567696e533a02000009000000010200000900000001"
    "0000190008637274656e64533a02000009000000010200000900000001"
    "00001600086372746e3a02000009000000010200000900000001"
)
EXPECTED_EXPORT_COUNT = 137
FSELF_MAGIC = b"\x4f\x15\x3d\x1d"


def fself_versions(data: bytes) -> tuple[int, int]:
    common_header_size = struct.calcsize("<4s4B")
    extended_header_size = struct.calcsize("<I2HQ2H4x")
    if data[:4] != FSELF_MAGIC:
        raise ValueError("SPRX is not a fake signed ELF image")
    _, _, _, _, num_entries, _ = struct.unpack_from(
        "<I2HQ2H4x", data, common_header_size
    )
    elf_offset = common_header_size + extended_header_size + num_entries * 32
    if data[elf_offset:elf_offset + 4] != b"\x7fELF":
        raise ValueError("SPRX does not contain an ELF header at the expected offset")
    phoff = struct.unpack_from("<Q", data, elf_offset + 0x20)[0]
    ehsize, phentsize, phnum = struct.unpack_from("<HHH", data, elf_offset + 0x34)
    elf_header_size = max(ehsize, phoff + phentsize * phnum)
    ex_info_offset = elf_offset + ((elf_header_size + 15) & ~15)
    _, _, app_version, fw_version = struct.unpack_from("<4Q", data, ex_info_offset)
    return app_version, fw_version


MIB = 1 << 20
# The release and debug PRX must have the same size (Makefile
# AMPR_INTERNAL_POOL_SIZE / AMPR_DEBUG_POOL_SIZE), below PRX_TOTAL_LIMIT.
# v0.3.4 loaded at 200.7 MiB, so 192 MiB is known to load.
PRX_TOTAL_LIMIT = 192 * MIB
PRX_TOTAL_SLACK = 64 << 10


def pt_load_total(data: bytes) -> int:
    """Sum of PT_LOAD p_memsz: the PRX's memory once loaded."""
    phoff = struct.unpack_from("<Q", data, 0x20)[0]
    phentsize, phnum = struct.unpack_from("<HH", data, 0x36)
    total = 0
    for i in range(phnum):
        p_type = struct.unpack_from("<I", data, phoff + i * phentsize)[0]
        if p_type == 1:
            total += struct.unpack_from("<Q", data, phoff + i * phentsize + 0x28)[0]
    return total


def check_prx_totals(release: Path, debug: Path) -> int:
    """Fails unless both PRX totals match within 64 KiB and stay below the limit."""
    rel, dbg = pt_load_total(release.read_bytes()), pt_load_total(debug.read_bytes())
    gap = abs(rel - dbg)
    print(
        f"prx_totals release={rel} ({rel / MIB:.2f} MiB) "
        f"debug={dbg} ({dbg / MIB:.2f} MiB) diff={gap}"
    )
    if gap > PRX_TOTAL_SLACK or max(rel, dbg) >= PRX_TOTAL_LIMIT:
        raise ValueError(
            "release and debug PRX totals must match within 64 KiB and stay "
            f"below {PRX_TOTAL_LIMIT // MIB} MiB: update the pool gap in the "
            "Makefile (debug - release "
            f"= {dbg - rel:+d} B; move that, in 16 KiB pages, from "
            "AMPR_DEBUG_POOL_SIZE to AMPR_INTERNAL_POOL_SIZE)"
        )
    return 0


def main() -> int:
    if len(sys.argv) == 4 and sys.argv[1] == "--prx-totals":
        return check_prx_totals(Path(sys.argv[2]), Path(sys.argv[3]))
    parser = argparse.ArgumentParser()
    parser.add_argument("--prx", type=Path, required=True)
    parser.add_argument("--linked", type=Path, required=True)
    parser.add_argument("--libc-imports", type=Path, required=True)
    parser.add_argument("--kernel-imports", type=Path, required=True)
    parser.add_argument("--defined", type=Path, required=True)
    parser.add_argument("--sprx", type=Path, required=True)
    parser.add_argument("--fself-version", type=lambda value: int(value, 0), required=True)
    args = parser.parse_args()

    data = args.prx.read_bytes()
    linked_data = args.linked.read_bytes()
    app_version, fw_version = fself_versions(args.sprx.read_bytes())
    if app_version != args.fself_version or fw_version != args.fself_version:
        raise ValueError(
            "unexpected FSELF versions: "
            f"app=0x{app_version:08x} fw=0x{fw_version:08x} "
            f"expected=0x{args.fself_version:08x}"
        )
    if data[:4] != b"\x7fELF" or data[7] != 9 or data[8] != 2:
        raise ValueError("PRX is not an ELF64 FreeBSD ABI v2 image")
    if struct.unpack_from("<H", data, 0x10)[0] != 0xFE18:
        raise ValueError("PRX e_type is not ET_SCE_DYNAMIC (0xfe18)")
    phoff = struct.unpack_from("<Q", data, 0x20)[0]
    phentsize, phnum = struct.unpack_from("<HH", data, 0x36)
    if phentsize < 56 or phnum != len(EXPECTED_PHDR_TYPES):
        raise ValueError(
            f"unexpected PRX program headers: phentsize={phentsize} phnum={phnum}"
        )
    phdr_types = [
        struct.unpack_from("<I", data, phoff + index * phentsize)[0]
        for index in range(phnum)
    ]
    if phdr_types != EXPECTED_PHDR_TYPES:
        raise ValueError(f"PRX program-header layout mismatch: {phdr_types}")

    elf = Elf64LE(data)
    module_param = elf.section(".sce_module_param")
    if data[module_param.offset:module_param.offset + module_param.size] != EXPECTED_MODULE_PARAM:
        raise ValueError("repository CRT emitted an unexpected .sce_module_param")
    sceversion = elf.section(".sceversion")
    if data[sceversion.offset:sceversion.offset + sceversion.size] != EXPECTED_SCEVERSION:
        raise ValueError("repository CRT emitted unexpected .sceversion records")
    if not elf.section(".init").size or not elf.section(".fini").size:
        raise ValueError("repository CRT did not emit _init/_fini sections")
    if len(linked_data) != len(data):
        raise ValueError("hash correction changed the PRX size")
    hash_section = elf.section(".hash")
    changed = [
        index for index, pair in enumerate(zip(linked_data, data))
        if pair[0] != pair[1]
    ]
    if not changed:
        raise ValueError("hash correction did not change the linked PRX")
    escaped = [
        index for index in changed
        if not hash_section.offset <= index < hash_section.offset + hash_section.size
    ]
    if escaped:
        raise ValueError(f"hash correction changed byte outside .hash: 0x{escaped[0]:x}")
    dynstr = elf.section(".dynstr")
    dynsyms = elf.dynsyms()
    groups = elf.export_groups()
    matching_groups = {
        suffix: group
        for suffix, group in groups.items()
        if group.library == "libSceAmpr" and group.module == "libSceAmpr"
    }
    if len(matching_groups) != 1:
        raise ValueError("missing unique libSceAmpr SCE export group")
    (export_suffix, group), = matching_groups.items()

    export_names = set(defined_exports(args.defined))
    if len(export_names) != EXPECTED_EXPORT_COUNT:
        raise ValueError(
            f"unexpected object export count: {len(export_names)} "
            f"(expected {EXPECTED_EXPORT_COUNT})"
        )

    expected = {
        f"{name_to_nid(name)}#{export_suffix[0]}#{export_suffix[1]}"
        for name in export_names
    }
    actual = {
        sym.name
        for sym in dynsyms[1:]
        if sym.st_shndx != 0 and sym.nid_parts and sym.nid_parts[1:] == export_suffix
    }
    missing = sorted(expected - actual)
    extra = sorted(actual - expected)
    if missing or extra:
        raise ValueError(f"payload export mismatch: missing={missing} extra={extra}")

    defined = {
        sym.name for sym in dynsyms[1:] if sym.st_shndx != 0 and sym.name
    }
    allowed_defined = expected | set(METADATA_SYMBOLS)
    unexpected_defined = sorted(defined - allowed_defined)
    missing_metadata = sorted(set(METADATA_SYMBOLS) - defined)
    if unexpected_defined or missing_metadata:
        raise ValueError(
            "unexpected dynamic definitions: "
            f"extra={unexpected_defined} missing_metadata={missing_metadata}"
        )

    imports = [sym.name for sym in dynsyms[1:] if sym.st_shndx == 0 and sym.name]
    bad_imports = sorted(name for name in imports if not IMPORT_RE.fullmatch(name))
    if bad_imports:
        raise ValueError(f"plain or malformed imports remain: {bad_imports}")
    libc_names = {
        line.strip()
        for line in args.libc_imports.read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    expected_libc = {f"{name_to_nid(name)}#A#B" for name in libc_names}
    actual_libc = {name for name in imports if name.endswith("#A#B")}
    # An import listed but absent was dropped with the code that used it
    # (--gc-sections after the list was taken from the combined object).
    if not actual_libc <= expected_libc:
        raise ValueError(
            "libSceLibcInternal import mismatch: "
            f"missing={sorted(expected_libc - actual_libc)} "
            f"extra={sorted(actual_libc - expected_libc)}"
        )
    kernel_names = {
        line.strip()
        for line in args.kernel_imports.read_text(encoding="utf-8").splitlines()
        if line.strip()
    }
    expected_kernel = {f"{name_to_nid(name)}#B#C" for name in kernel_names}
    actual_kernel = set(imports) - actual_libc
    # An import listed but absent was dropped with the code that used it
    # (--gc-sections after the list was taken from the combined object).
    if not actual_kernel <= expected_kernel:
        raise ValueError(
            "libkernel import mismatch: "
            f"missing={sorted(expected_kernel - actual_kernel)} "
            f"extra={sorted(actual_kernel - expected_kernel)}"
        )

    needed = []
    soname = None
    for tag, value in elf.dynamic_entries():
        if tag == 1:
            needed.append(elf.str_at(dynstr, value))
        elif tag == 14:
            soname = elf.str_at(dynstr, value)
    if needed != ["libSceLibcInternal.prx", "libkernel.prx"] or soname is not None:
        raise ValueError(f"unexpected dynamic libraries: needed={needed} soname={soname}")

    _, nbucket, _, buckets, chains = elf.hash_table()
    actual_buckets = buckets_to_symbol_map(buckets, chains)
    bad_buckets = []
    for sym in dynsyms[1:]:
        if sym.name not in actual:
            continue
        nid = sym.nid_parts[0]
        expected_bucket = elf_hash(group.canonical(nid)) % nbucket
        if actual_buckets.get(sym.index) != expected_bucket:
            bad_buckets.append((sym.name, actual_buckets.get(sym.index), expected_bucket))
    if bad_buckets:
        raise ValueError(f"incorrect export hash buckets: {bad_buckets}")

    print(
        f"payload_prx_ok exports={len(actual)} definitions={len(defined)} "
        f"imports={len(imports)} "
        f"libc_internal_imports={len(actual_libc)} "
        f"kernel_imports={len(actual_kernel)} "
        f"hash_buckets={nbucket} hash_changed_bytes={len(changed)} "
        f"fself_version=0x{fw_version:08x} "
        "needed=libSceLibcInternal.prx,libkernel.prx"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
